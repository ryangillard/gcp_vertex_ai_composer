# -*- coding: utf-8 -*-
# Copyright 2020 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import proto  # type: ignore

from google.cloud.aiplatform_v1beta1.types import batch_prediction_job as gca_batch_prediction_job
from google.cloud.aiplatform_v1beta1.types import nas_job as gca_nas_job
from google.protobuf import field_mask_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.aiplatform.v1beta1',
    manifest={
        'CreateNasJobRequest',
        'GetNasJobRequest',
        'ListNasJobsRequest',
        'ListNasJobsResponse',
        'DeleteNasJobRequest',
        'CancelNasJobRequest',
        'GetNasTrialDetailRequest',
        'ListNasTrialDetailsRequest',
        'ListNasTrialDetailsResponse',
        'CreateBatchPredictionJobRequest',
        'GetBatchPredictionJobRequest',
        'ListBatchPredictionJobsRequest',
        'ListBatchPredictionJobsResponse',
        'DeleteBatchPredictionJobRequest',
        'CancelBatchPredictionJobRequest',
    },
)


class CreateNasJobRequest(proto.Message):
    r"""Request message for
    [JobService.CreateNasJob][google.cloud.aiplatform.v1beta1.JobService.CreateNasJob].

    Attributes:
        parent (str):
            Required. The resource name of the Location to create the
            NasJob in. Format:
            ``projects/{project}/locations/{location}``
        nas_job (google.cloud.aiplatform_v1beta1.types.NasJob):
            Required. The NasJob to create.
    """

    parent = proto.Field(
        proto.STRING,
        number=1,
    )
    nas_job = proto.Field(
        proto.MESSAGE,
        number=2,
        message=gca_nas_job.NasJob,
    )


class GetNasJobRequest(proto.Message):
    r"""Request message for
    [JobService.GetNasJob][google.cloud.aiplatform.v1beta1.JobService.GetNasJob].

    Attributes:
        name (str):
            Required. The name of the NasJob resource. Format:
            ``projects/{project}/locations/{location}/nasJobs/{nas_job}``
    """

    name = proto.Field(
        proto.STRING,
        number=1,
    )


class ListNasJobsRequest(proto.Message):
    r"""Request message for
    [JobService.ListNasJobs][google.cloud.aiplatform.v1beta1.JobService.ListNasJobs].

    Attributes:
        parent (str):
            Required. The resource name of the Location to list the
            NasJobs from. Format:
            ``projects/{project}/locations/{location}``
        filter (str):
            The standard list filter.

            Supported fields:

            -  ``display_name`` supports = and !=.

            -  ``state`` supports = and !=.

            Some examples of using the filter are:

            -  ``state="JOB_STATE_SUCCEEDED" AND display_name="my_job"``

            -  ``state="JOB_STATE_RUNNING" OR display_name="my_job"``

            -  ``NOT display_name="my_job"``

            -  ``state="JOB_STATE_FAILED"``
        page_size (int):
            The standard list page size.
        page_token (str):
            The standard list page token. Typically obtained via
            [ListNasJobsResponse.next_page_token][google.cloud.aiplatform.v1beta1.ListNasJobsResponse.next_page_token]
            of the previous
            [JobService.ListNasJobs][google.cloud.aiplatform.v1beta1.JobService.ListNasJobs]
            call.
        read_mask (google.protobuf.field_mask_pb2.FieldMask):
            Mask specifying which fields to read.
    """

    parent = proto.Field(
        proto.STRING,
        number=1,
    )
    filter = proto.Field(
        proto.STRING,
        number=2,
    )
    page_size = proto.Field(
        proto.INT32,
        number=3,
    )
    page_token = proto.Field(
        proto.STRING,
        number=4,
    )
    read_mask = proto.Field(
        proto.MESSAGE,
        number=5,
        message=field_mask_pb2.FieldMask,
    )


class ListNasJobsResponse(proto.Message):
    r"""Response message for
    [JobService.ListNasJobs][google.cloud.aiplatform.v1beta1.JobService.ListNasJobs]

    Attributes:
        nas_jobs (Sequence[google.cloud.aiplatform_v1beta1.types.NasJob]):
            List of NasJobs in the requested page.
            [NasJob.nas_job_output][google.cloud.aiplatform.v1beta1.NasJob.nas_job_output]
            of the jobs will not be returned.
        next_page_token (str):
            A token to retrieve the next page of results. Pass to
            [ListNasJobsRequest.page_token][google.cloud.aiplatform.v1beta1.ListNasJobsRequest.page_token]
            to obtain that page.
    """

    @property
    def raw_page(self):
        return self

    nas_jobs = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message=gca_nas_job.NasJob,
    )
    next_page_token = proto.Field(
        proto.STRING,
        number=2,
    )


class DeleteNasJobRequest(proto.Message):
    r"""Request message for
    [JobService.DeleteNasJob][google.cloud.aiplatform.v1beta1.JobService.DeleteNasJob].

    Attributes:
        name (str):
            Required. The name of the NasJob resource to be deleted.
            Format:
            ``projects/{project}/locations/{location}/nasJobs/{nas_job}``
    """

    name = proto.Field(
        proto.STRING,
        number=1,
    )


class CancelNasJobRequest(proto.Message):
    r"""Request message for
    [JobService.CancelNasJob][google.cloud.aiplatform.v1beta1.JobService.CancelNasJob].

    Attributes:
        name (str):
            Required. The name of the NasJob to cancel. Format:
            ``projects/{project}/locations/{location}/nasJobs/{nas_job}``
    """

    name = proto.Field(
        proto.STRING,
        number=1,
    )


class GetNasTrialDetailRequest(proto.Message):
    r"""Request message for
    [JobService.GetNasTrialDetail][google.cloud.aiplatform.v1beta1.JobService.GetNasTrialDetail].

    Attributes:
        name (str):
            Required. The name of the NasTrialDetail resource. Format:
            ``projects/{project}/locations/{location}/nasJobs/{nas_job}/nasTrialDetails/{nas_trial_detail}``
    """

    name = proto.Field(
        proto.STRING,
        number=1,
    )


class ListNasTrialDetailsRequest(proto.Message):
    r"""Request message for
    [JobService.ListNasTrialDetails][google.cloud.aiplatform.v1beta1.JobService.ListNasTrialDetails].

    Attributes:
        parent (str):
            Required. The name of the NasJob resource. Format:
            ``projects/{project}/locations/{location}/nasJobs/{nas_job}``
        page_size (int):
            The standard list page size.
        page_token (str):
            The standard list page token. Typically obtained via
            [ListNasTrialDetailsResponse.next_page_token][google.cloud.aiplatform.v1beta1.ListNasTrialDetailsResponse.next_page_token]
            of the previous
            [JobService.ListNasTrialDetails][google.cloud.aiplatform.v1beta1.JobService.ListNasTrialDetails]
            call.
    """

    parent = proto.Field(
        proto.STRING,
        number=1,
    )
    page_size = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token = proto.Field(
        proto.STRING,
        number=3,
    )


class ListNasTrialDetailsResponse(proto.Message):
    r"""Response message for
    [JobService.ListNasTrialDetails][google.cloud.aiplatform.v1beta1.JobService.ListNasTrialDetails]

    Attributes:
        nas_trial_details (Sequence[google.cloud.aiplatform_v1beta1.types.NasTrialDetail]):
            List of top NasTrials in the requested page.
        next_page_token (str):
            A token to retrieve the next page of results. Pass to
            [ListNasTrialDetailsRequest.page_token][google.cloud.aiplatform.v1beta1.ListNasTrialDetailsRequest.page_token]
            to obtain that page.
    """

    @property
    def raw_page(self):
        return self

    nas_trial_details = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message=gca_nas_job.NasTrialDetail,
    )
    next_page_token = proto.Field(
        proto.STRING,
        number=2,
    )


class CreateBatchPredictionJobRequest(proto.Message):
    r"""Request message for
    [JobService.CreateBatchPredictionJob][google.cloud.aiplatform.v1beta1.JobService.CreateBatchPredictionJob].

    Attributes:
        parent (str):
            Required. The resource name of the Location to create the
            BatchPredictionJob in. Format:
            ``projects/{project}/locations/{location}``
        batch_prediction_job (google.cloud.aiplatform_v1beta1.types.BatchPredictionJob):
            Required. The BatchPredictionJob to create.
    """

    parent = proto.Field(
        proto.STRING,
        number=1,
    )
    batch_prediction_job = proto.Field(
        proto.MESSAGE,
        number=2,
        message=gca_batch_prediction_job.BatchPredictionJob,
    )


class GetBatchPredictionJobRequest(proto.Message):
    r"""Request message for
    [JobService.GetBatchPredictionJob][google.cloud.aiplatform.v1beta1.JobService.GetBatchPredictionJob].

    Attributes:
        name (str):
            Required. The name of the BatchPredictionJob resource.
            Format:
            ``projects/{project}/locations/{location}/batchPredictionJobs/{batch_prediction_job}``
    """

    name = proto.Field(
        proto.STRING,
        number=1,
    )


class ListBatchPredictionJobsRequest(proto.Message):
    r"""Request message for
    [JobService.ListBatchPredictionJobs][google.cloud.aiplatform.v1beta1.JobService.ListBatchPredictionJobs].

    Attributes:
        parent (str):
            Required. The resource name of the Location to list the
            BatchPredictionJobs from. Format:
            ``projects/{project}/locations/{location}``
        filter (str):
            The standard list filter.

            Supported fields:

            -  ``display_name`` supports = and !=.

            -  ``state`` supports = and !=.

            -  ``model_display_name`` supports = and !=

            Some examples of using the filter are:

            -  ``state="JOB_STATE_SUCCEEDED" AND display_name="my_job"``

            -  ``state="JOB_STATE_RUNNING" OR display_name="my_job"``

            -  ``NOT display_name="my_job"``

            -  ``state="JOB_STATE_FAILED"``
        page_size (int):
            The standard list page size.
        page_token (str):
            The standard list page token. Typically obtained via
            [ListBatchPredictionJobsResponse.next_page_token][google.cloud.aiplatform.v1beta1.ListBatchPredictionJobsResponse.next_page_token]
            of the previous
            [JobService.ListBatchPredictionJobs][google.cloud.aiplatform.v1beta1.JobService.ListBatchPredictionJobs]
            call.
        read_mask (google.protobuf.field_mask_pb2.FieldMask):
            Mask specifying which fields to read.
    """

    parent = proto.Field(
        proto.STRING,
        number=1,
    )
    filter = proto.Field(
        proto.STRING,
        number=2,
    )
    page_size = proto.Field(
        proto.INT32,
        number=3,
    )
    page_token = proto.Field(
        proto.STRING,
        number=4,
    )
    read_mask = proto.Field(
        proto.MESSAGE,
        number=5,
        message=field_mask_pb2.FieldMask,
    )


class ListBatchPredictionJobsResponse(proto.Message):
    r"""Response message for
    [JobService.ListBatchPredictionJobs][google.cloud.aiplatform.v1beta1.JobService.ListBatchPredictionJobs]

    Attributes:
        batch_prediction_jobs (Sequence[google.cloud.aiplatform_v1beta1.types.BatchPredictionJob]):
            List of BatchPredictionJobs in the requested
            page.
        next_page_token (str):
            A token to retrieve the next page of results. Pass to
            [ListBatchPredictionJobsRequest.page_token][google.cloud.aiplatform.v1beta1.ListBatchPredictionJobsRequest.page_token]
            to obtain that page.
    """

    @property
    def raw_page(self):
        return self

    batch_prediction_jobs = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message=gca_batch_prediction_job.BatchPredictionJob,
    )
    next_page_token = proto.Field(
        proto.STRING,
        number=2,
    )


class DeleteBatchPredictionJobRequest(proto.Message):
    r"""Request message for
    [JobService.DeleteBatchPredictionJob][google.cloud.aiplatform.v1beta1.JobService.DeleteBatchPredictionJob].

    Attributes:
        name (str):
            Required. The name of the BatchPredictionJob resource to be
            deleted. Format:
            ``projects/{project}/locations/{location}/batchPredictionJobs/{batch_prediction_job}``
    """

    name = proto.Field(
        proto.STRING,
        number=1,
    )


class CancelBatchPredictionJobRequest(proto.Message):
    r"""Request message for
    [JobService.CancelBatchPredictionJob][google.cloud.aiplatform.v1beta1.JobService.CancelBatchPredictionJob].

    Attributes:
        name (str):
            Required. The name of the BatchPredictionJob to cancel.
            Format:
            ``projects/{project}/locations/{location}/batchPredictionJobs/{batch_prediction_job}``
    """

    name = proto.Field(
        proto.STRING,
        number=1,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
