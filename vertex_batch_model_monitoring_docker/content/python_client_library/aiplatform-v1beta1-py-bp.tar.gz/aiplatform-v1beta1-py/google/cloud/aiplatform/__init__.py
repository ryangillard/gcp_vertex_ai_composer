# -*- coding: utf-8 -*-
# Copyright 2020 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

from google.cloud.aiplatform_v1beta1.services.featurestore_online_serving_service.client import FeaturestoreOnlineServingServiceClient
from google.cloud.aiplatform_v1beta1.services.featurestore_online_serving_service.async_client import FeaturestoreOnlineServingServiceAsyncClient
from google.cloud.aiplatform_v1beta1.services.featurestore_service.client import FeaturestoreServiceClient
from google.cloud.aiplatform_v1beta1.services.featurestore_service.async_client import FeaturestoreServiceAsyncClient
from google.cloud.aiplatform_v1beta1.services.job_service.client import JobServiceClient
from google.cloud.aiplatform_v1beta1.services.job_service.async_client import JobServiceAsyncClient

from google.cloud.aiplatform_v1beta1.types.accelerator_type import AcceleratorType
from google.cloud.aiplatform_v1beta1.types.batch_prediction_job import BatchPredictionJob
from google.cloud.aiplatform_v1beta1.types.completion_stats import CompletionStats
from google.cloud.aiplatform_v1beta1.types.custom_job import ContainerSpec
from google.cloud.aiplatform_v1beta1.types.custom_job import CustomJobSpec
from google.cloud.aiplatform_v1beta1.types.custom_job import PythonPackageSpec
from google.cloud.aiplatform_v1beta1.types.custom_job import Scheduling
from google.cloud.aiplatform_v1beta1.types.custom_job import WorkerPoolSpec
from google.cloud.aiplatform_v1beta1.types.dataset import Dataset
from google.cloud.aiplatform_v1beta1.types.dataset import ExportDataConfig
from google.cloud.aiplatform_v1beta1.types.dataset import ImportDataConfig
from google.cloud.aiplatform_v1beta1.types.deployed_model_ref import DeployedModelRef
from google.cloud.aiplatform_v1beta1.types.encryption_spec import EncryptionSpec
from google.cloud.aiplatform_v1beta1.types.endpoint import DeployedModel
from google.cloud.aiplatform_v1beta1.types.endpoint import Endpoint
from google.cloud.aiplatform_v1beta1.types.endpoint import PrivateEndpoints
from google.cloud.aiplatform_v1beta1.types.entity_type import EntityType
from google.cloud.aiplatform_v1beta1.types.env_var import EnvVar
from google.cloud.aiplatform_v1beta1.types.explanation import Attribution
from google.cloud.aiplatform_v1beta1.types.explanation import Explanation
from google.cloud.aiplatform_v1beta1.types.explanation import ExplanationMetadataOverride
from google.cloud.aiplatform_v1beta1.types.explanation import ExplanationParameters
from google.cloud.aiplatform_v1beta1.types.explanation import ExplanationSpec
from google.cloud.aiplatform_v1beta1.types.explanation import ExplanationSpecOverride
from google.cloud.aiplatform_v1beta1.types.explanation import FeatureNoiseSigma
from google.cloud.aiplatform_v1beta1.types.explanation import IntegratedGradientsAttribution
from google.cloud.aiplatform_v1beta1.types.explanation import ModelExplanation
from google.cloud.aiplatform_v1beta1.types.explanation import SampledShapleyAttribution
from google.cloud.aiplatform_v1beta1.types.explanation import Similarity
from google.cloud.aiplatform_v1beta1.types.explanation import SmoothGradConfig
from google.cloud.aiplatform_v1beta1.types.explanation import XraiAttribution
from google.cloud.aiplatform_v1beta1.types.explanation_metadata import ExplanationMetadata
from google.cloud.aiplatform_v1beta1.types.feature import Feature
from google.cloud.aiplatform_v1beta1.types.feature_monitoring_stats import FeatureStatsAnomaly
from google.cloud.aiplatform_v1beta1.types.feature_selector import FeatureSelector
from google.cloud.aiplatform_v1beta1.types.feature_selector import IdMatcher
from google.cloud.aiplatform_v1beta1.types.featurestore import Featurestore
from google.cloud.aiplatform_v1beta1.types.featurestore_monitoring import FeaturestoreMonitoringConfig
from google.cloud.aiplatform_v1beta1.types.featurestore_online_service import FeatureValue
from google.cloud.aiplatform_v1beta1.types.featurestore_online_service import FeatureValueList
from google.cloud.aiplatform_v1beta1.types.featurestore_online_service import ReadFeatureValuesRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_online_service import ReadFeatureValuesResponse
from google.cloud.aiplatform_v1beta1.types.featurestore_online_service import StreamingReadFeatureValuesRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_online_service import WriteFeatureValuesPayload
from google.cloud.aiplatform_v1beta1.types.featurestore_online_service import WriteFeatureValuesRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_online_service import WriteFeatureValuesResponse
from google.cloud.aiplatform_v1beta1.types.featurestore_service import BatchCreateFeaturesOperationMetadata
from google.cloud.aiplatform_v1beta1.types.featurestore_service import BatchCreateFeaturesRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import BatchCreateFeaturesResponse
from google.cloud.aiplatform_v1beta1.types.featurestore_service import BatchReadFeatureValuesOperationMetadata
from google.cloud.aiplatform_v1beta1.types.featurestore_service import BatchReadFeatureValuesRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import BatchReadFeatureValuesResponse
from google.cloud.aiplatform_v1beta1.types.featurestore_service import CreateEntityTypeOperationMetadata
from google.cloud.aiplatform_v1beta1.types.featurestore_service import CreateEntityTypeRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import CreateFeatureOperationMetadata
from google.cloud.aiplatform_v1beta1.types.featurestore_service import CreateFeatureRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import CreateFeaturestoreOperationMetadata
from google.cloud.aiplatform_v1beta1.types.featurestore_service import CreateFeaturestoreRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import DeleteEntityTypeRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import DeleteFeatureRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import DeleteFeaturestoreRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import DestinationFeatureSetting
from google.cloud.aiplatform_v1beta1.types.featurestore_service import ExportFeatureValuesOperationMetadata
from google.cloud.aiplatform_v1beta1.types.featurestore_service import ExportFeatureValuesRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import ExportFeatureValuesResponse
from google.cloud.aiplatform_v1beta1.types.featurestore_service import FeatureValueDestination
from google.cloud.aiplatform_v1beta1.types.featurestore_service import GetEntityTypeRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import GetFeatureRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import GetFeaturestoreRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import ImportFeatureValuesOperationMetadata
from google.cloud.aiplatform_v1beta1.types.featurestore_service import ImportFeatureValuesRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import ImportFeatureValuesResponse
from google.cloud.aiplatform_v1beta1.types.featurestore_service import ListEntityTypesRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import ListEntityTypesResponse
from google.cloud.aiplatform_v1beta1.types.featurestore_service import ListFeaturesRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import ListFeaturesResponse
from google.cloud.aiplatform_v1beta1.types.featurestore_service import ListFeaturestoresRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import ListFeaturestoresResponse
from google.cloud.aiplatform_v1beta1.types.featurestore_service import SearchFeaturesRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import SearchFeaturesResponse
from google.cloud.aiplatform_v1beta1.types.featurestore_service import UpdateEntityTypeRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import UpdateFeatureRequest
from google.cloud.aiplatform_v1beta1.types.featurestore_service import UpdateFeaturestoreOperationMetadata
from google.cloud.aiplatform_v1beta1.types.featurestore_service import UpdateFeaturestoreRequest
from google.cloud.aiplatform_v1beta1.types.io import AvroSource
from google.cloud.aiplatform_v1beta1.types.io import BigQueryDestination
from google.cloud.aiplatform_v1beta1.types.io import BigQuerySource
from google.cloud.aiplatform_v1beta1.types.io import ContainerRegistryDestination
from google.cloud.aiplatform_v1beta1.types.io import CsvDestination
from google.cloud.aiplatform_v1beta1.types.io import CsvSource
from google.cloud.aiplatform_v1beta1.types.io import GcsDestination
from google.cloud.aiplatform_v1beta1.types.io import GcsSource
from google.cloud.aiplatform_v1beta1.types.io import TFRecordDestination
from google.cloud.aiplatform_v1beta1.types.job_service import CancelBatchPredictionJobRequest
from google.cloud.aiplatform_v1beta1.types.job_service import CancelNasJobRequest
from google.cloud.aiplatform_v1beta1.types.job_service import CreateBatchPredictionJobRequest
from google.cloud.aiplatform_v1beta1.types.job_service import CreateNasJobRequest
from google.cloud.aiplatform_v1beta1.types.job_service import DeleteBatchPredictionJobRequest
from google.cloud.aiplatform_v1beta1.types.job_service import DeleteNasJobRequest
from google.cloud.aiplatform_v1beta1.types.job_service import GetBatchPredictionJobRequest
from google.cloud.aiplatform_v1beta1.types.job_service import GetNasJobRequest
from google.cloud.aiplatform_v1beta1.types.job_service import GetNasTrialDetailRequest
from google.cloud.aiplatform_v1beta1.types.job_service import ListBatchPredictionJobsRequest
from google.cloud.aiplatform_v1beta1.types.job_service import ListBatchPredictionJobsResponse
from google.cloud.aiplatform_v1beta1.types.job_service import ListNasJobsRequest
from google.cloud.aiplatform_v1beta1.types.job_service import ListNasJobsResponse
from google.cloud.aiplatform_v1beta1.types.job_service import ListNasTrialDetailsRequest
from google.cloud.aiplatform_v1beta1.types.job_service import ListNasTrialDetailsResponse
from google.cloud.aiplatform_v1beta1.types.job_state import JobState
from google.cloud.aiplatform_v1beta1.types.machine_resources import AutomaticResources
from google.cloud.aiplatform_v1beta1.types.machine_resources import AutoscalingMetricSpec
from google.cloud.aiplatform_v1beta1.types.machine_resources import BatchDedicatedResources
from google.cloud.aiplatform_v1beta1.types.machine_resources import DedicatedResources
from google.cloud.aiplatform_v1beta1.types.machine_resources import DiskSpec
from google.cloud.aiplatform_v1beta1.types.machine_resources import MachineSpec
from google.cloud.aiplatform_v1beta1.types.machine_resources import ResourcesConsumed
from google.cloud.aiplatform_v1beta1.types.manual_batch_tuning_parameters import ManualBatchTuningParameters
from google.cloud.aiplatform_v1beta1.types.model import Model
from google.cloud.aiplatform_v1beta1.types.model import ModelContainerSpec
from google.cloud.aiplatform_v1beta1.types.model import Port
from google.cloud.aiplatform_v1beta1.types.model import PredictSchemata
from google.cloud.aiplatform_v1beta1.types.model_monitoring import ModelMonitoringAlertConfig
from google.cloud.aiplatform_v1beta1.types.model_monitoring import ModelMonitoringConfig
from google.cloud.aiplatform_v1beta1.types.model_monitoring import ModelMonitoringObjectiveConfig
from google.cloud.aiplatform_v1beta1.types.model_monitoring import SamplingStrategy
from google.cloud.aiplatform_v1beta1.types.model_monitoring import ThresholdConfig
from google.cloud.aiplatform_v1beta1.types.nas_job import NasJob
from google.cloud.aiplatform_v1beta1.types.nas_job import NasJobOutput
from google.cloud.aiplatform_v1beta1.types.nas_job import NasJobSpec
from google.cloud.aiplatform_v1beta1.types.nas_job import NasTrial
from google.cloud.aiplatform_v1beta1.types.nas_job import NasTrialDetail
from google.cloud.aiplatform_v1beta1.types.operation import DeleteOperationMetadata
from google.cloud.aiplatform_v1beta1.types.operation import GenericOperationMetadata
from google.cloud.aiplatform_v1beta1.types.pipeline_state import PipelineState
from google.cloud.aiplatform_v1beta1.types.study import Measurement
from google.cloud.aiplatform_v1beta1.types.study import Study
from google.cloud.aiplatform_v1beta1.types.study import StudySpec
from google.cloud.aiplatform_v1beta1.types.study import Trial
from google.cloud.aiplatform_v1beta1.types.training_pipeline import FilterSplit
from google.cloud.aiplatform_v1beta1.types.training_pipeline import FractionSplit
from google.cloud.aiplatform_v1beta1.types.training_pipeline import InputDataConfig
from google.cloud.aiplatform_v1beta1.types.training_pipeline import PredefinedSplit
from google.cloud.aiplatform_v1beta1.types.training_pipeline import StratifiedSplit
from google.cloud.aiplatform_v1beta1.types.training_pipeline import TimestampSplit
from google.cloud.aiplatform_v1beta1.types.training_pipeline import TrainingPipeline
from google.cloud.aiplatform_v1beta1.types.types import BoolArray
from google.cloud.aiplatform_v1beta1.types.types import DoubleArray
from google.cloud.aiplatform_v1beta1.types.types import Int64Array
from google.cloud.aiplatform_v1beta1.types.types import StringArray
from google.cloud.aiplatform_v1beta1.types.unmanaged_container_model import UnmanagedContainerModel

__all__ = ('FeaturestoreOnlineServingServiceClient',
    'FeaturestoreOnlineServingServiceAsyncClient',
    'FeaturestoreServiceClient',
    'FeaturestoreServiceAsyncClient',
    'JobServiceClient',
    'JobServiceAsyncClient',
    'AcceleratorType',
    'BatchPredictionJob',
    'CompletionStats',
    'ContainerSpec',
    'CustomJobSpec',
    'PythonPackageSpec',
    'Scheduling',
    'WorkerPoolSpec',
    'Dataset',
    'ExportDataConfig',
    'ImportDataConfig',
    'DeployedModelRef',
    'EncryptionSpec',
    'DeployedModel',
    'Endpoint',
    'PrivateEndpoints',
    'EntityType',
    'EnvVar',
    'Attribution',
    'Explanation',
    'ExplanationMetadataOverride',
    'ExplanationParameters',
    'ExplanationSpec',
    'ExplanationSpecOverride',
    'FeatureNoiseSigma',
    'IntegratedGradientsAttribution',
    'ModelExplanation',
    'SampledShapleyAttribution',
    'Similarity',
    'SmoothGradConfig',
    'XraiAttribution',
    'ExplanationMetadata',
    'Feature',
    'FeatureStatsAnomaly',
    'FeatureSelector',
    'IdMatcher',
    'Featurestore',
    'FeaturestoreMonitoringConfig',
    'FeatureValue',
    'FeatureValueList',
    'ReadFeatureValuesRequest',
    'ReadFeatureValuesResponse',
    'StreamingReadFeatureValuesRequest',
    'WriteFeatureValuesPayload',
    'WriteFeatureValuesRequest',
    'WriteFeatureValuesResponse',
    'BatchCreateFeaturesOperationMetadata',
    'BatchCreateFeaturesRequest',
    'BatchCreateFeaturesResponse',
    'BatchReadFeatureValuesOperationMetadata',
    'BatchReadFeatureValuesRequest',
    'BatchReadFeatureValuesResponse',
    'CreateEntityTypeOperationMetadata',
    'CreateEntityTypeRequest',
    'CreateFeatureOperationMetadata',
    'CreateFeatureRequest',
    'CreateFeaturestoreOperationMetadata',
    'CreateFeaturestoreRequest',
    'DeleteEntityTypeRequest',
    'DeleteFeatureRequest',
    'DeleteFeaturestoreRequest',
    'DestinationFeatureSetting',
    'ExportFeatureValuesOperationMetadata',
    'ExportFeatureValuesRequest',
    'ExportFeatureValuesResponse',
    'FeatureValueDestination',
    'GetEntityTypeRequest',
    'GetFeatureRequest',
    'GetFeaturestoreRequest',
    'ImportFeatureValuesOperationMetadata',
    'ImportFeatureValuesRequest',
    'ImportFeatureValuesResponse',
    'ListEntityTypesRequest',
    'ListEntityTypesResponse',
    'ListFeaturesRequest',
    'ListFeaturesResponse',
    'ListFeaturestoresRequest',
    'ListFeaturestoresResponse',
    'SearchFeaturesRequest',
    'SearchFeaturesResponse',
    'UpdateEntityTypeRequest',
    'UpdateFeatureRequest',
    'UpdateFeaturestoreOperationMetadata',
    'UpdateFeaturestoreRequest',
    'AvroSource',
    'BigQueryDestination',
    'BigQuerySource',
    'ContainerRegistryDestination',
    'CsvDestination',
    'CsvSource',
    'GcsDestination',
    'GcsSource',
    'TFRecordDestination',
    'CancelBatchPredictionJobRequest',
    'CancelNasJobRequest',
    'CreateBatchPredictionJobRequest',
    'CreateNasJobRequest',
    'DeleteBatchPredictionJobRequest',
    'DeleteNasJobRequest',
    'GetBatchPredictionJobRequest',
    'GetNasJobRequest',
    'GetNasTrialDetailRequest',
    'ListBatchPredictionJobsRequest',
    'ListBatchPredictionJobsResponse',
    'ListNasJobsRequest',
    'ListNasJobsResponse',
    'ListNasTrialDetailsRequest',
    'ListNasTrialDetailsResponse',
    'JobState',
    'AutomaticResources',
    'AutoscalingMetricSpec',
    'BatchDedicatedResources',
    'DedicatedResources',
    'DiskSpec',
    'MachineSpec',
    'ResourcesConsumed',
    'ManualBatchTuningParameters',
    'Model',
    'ModelContainerSpec',
    'Port',
    'PredictSchemata',
    'ModelMonitoringAlertConfig',
    'ModelMonitoringConfig',
    'ModelMonitoringObjectiveConfig',
    'SamplingStrategy',
    'ThresholdConfig',
    'NasJob',
    'NasJobOutput',
    'NasJobSpec',
    'NasTrial',
    'NasTrialDetail',
    'DeleteOperationMetadata',
    'GenericOperationMetadata',
    'PipelineState',
    'Measurement',
    'Study',
    'StudySpec',
    'Trial',
    'FilterSplit',
    'FractionSplit',
    'InputDataConfig',
    'PredefinedSplit',
    'StratifiedSplit',
    'TimestampSplit',
    'TrainingPipeline',
    'BoolArray',
    'DoubleArray',
    'Int64Array',
    'StringArray',
    'UnmanagedContainerModel',
)
